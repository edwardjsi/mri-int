"""
Action recording endpoints: mark signals as executed/skipped.
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional

from api.deps import get_db, get_current_client

router = APIRouter(prefix="/api/actions", tags=["actions"])


class RecordActionRequest(BaseModel):
    signal_id: str
    action_taken: str          # 'EXECUTED', 'SKIPPED', 'PARTIAL'
    actual_price: Optional[float] = None
    quantity: Optional[int] = None
    notes: Optional[str] = None


@router.post("/record")
def record_action(
    req: RecordActionRequest,
    client=Depends(get_current_client),
    conn=Depends(get_db),
):
    """Record a client's action on a signal (executed, skipped, partial)."""
    cur = conn.cursor()

    # Verify signal belongs to this client
    cur.execute(
        "SELECT id, symbol, action, recommended_price FROM client_signals WHERE id = %s AND client_id = %s",
        (req.signal_id, str(client["id"])),
    )
    signal = cur.fetchone()
    if not signal:
        cur.close()
        raise HTTPException(status_code=404, detail="Signal not found")

    is_dict = isinstance(signal, dict)
    rec_price = signal["recommended_price"] if is_dict else signal[3]
    sig_symbol = signal["symbol"] if is_dict else signal[1]
    sig_action = signal["action"] if is_dict else signal[2]

    # Use recommended price if no actual price provided
    actual_price = req.actual_price or float(rec_price)

    # Check for duplicate action
    cur.execute(
        "SELECT id FROM client_actions WHERE signal_id = %s AND client_id = %s",
        (req.signal_id, str(client["id"])),
    )
    if cur.fetchone():
        raise HTTPException(status_code=400, detail="Action already recorded for this signal")

    # Insert action
    cur.execute("""
        INSERT INTO client_actions (client_id, signal_id, action_taken, actual_price, quantity, notes)
        VALUES (%s, %s, %s, %s, %s, %s)
        RETURNING id
    """, (str(client["id"]), req.signal_id, req.action_taken, actual_price, req.quantity, req.notes))
    res = cur.fetchone()
    action_id = str(res["id"] if isinstance(res, dict) else res[0])

    # If EXECUTED, update client_portfolio
    if req.action_taken == "EXECUTED" and req.quantity and req.quantity > 0:
        if signal["action"] == "BUY":
            cur.execute("""
                INSERT INTO client_portfolio (client_id, symbol, entry_date, entry_price, quantity, highest_price)
                VALUES (%s, %s, CURRENT_DATE, %s, %s, %s)
                ON CONFLICT (client_id, symbol, entry_date) DO NOTHING
            """, (str(client["id"]), signal["symbol"], actual_price, req.quantity, actual_price))
        elif signal["action"] == "SELL":
            # Close the open position
            cur.execute("""
                UPDATE client_portfolio
                SET is_open = false, exit_date = CURRENT_DATE, exit_price = %s, exit_reason = 'SIGNAL'
                WHERE client_id = %s AND symbol = %s AND is_open = true
            """, (actual_price, str(client["id"]), signal["symbol"]))

    conn.commit()

    return {
        "id": action_id,
        "signal_id": req.signal_id,
        "action_taken": req.action_taken,
        "actual_price": actual_price,
        "quantity": req.quantity,
        "message": "Action recorded successfully",
    }


@router.get("/history")
def get_action_history(
    client=Depends(get_current_client),
    conn=Depends(get_db),
):
    """Full audit trail of all client actions."""
    cur = conn.cursor()

    cur.execute(
        """
        SELECT
            EXISTS (
                SELECT 1
                FROM information_schema.columns
                WHERE table_name = 'client_actions' AND column_name = 'notes'
            ) AS has_notes,
            EXISTS (
                SELECT 1
                FROM information_schema.columns
                WHERE table_name = 'client_actions' AND column_name = 'recorded_at'
            ) AS has_recorded_at
        """
    )
    column_flags = cur.fetchone()
    has_notes = bool(column_flags["has_notes"])
    has_recorded_at = bool(column_flags["has_recorded_at"])

    notes_select = "ca.notes," if has_notes else "NULL::TEXT AS notes,"
    recorded_at_select = "ca.recorded_at" if has_recorded_at else "NOW() AS recorded_at"
    order_by_clause = "ca.recorded_at DESC" if has_recorded_at else "cs.date DESC"
    cur.execute(
        f"""
        SELECT ca.id, ca.action_taken, ca.actual_price, ca.quantity, {notes_select} {recorded_at_select},
               cs.date AS signal_date, cs.symbol, cs.action AS signal_action,
               cs.recommended_price, cs.score, cs.regime
        FROM client_actions ca
        JOIN client_signals cs ON cs.id = ca.signal_id
        WHERE ca.client_id = %s
        ORDER BY {order_by_clause}
        """,
        (str(client["id"]),),
    )
    actions = cur.fetchall()

    return [
        {
            "id": str(a["id"]),
            "signal_date": str(a["signal_date"]),
            "symbol": a["symbol"],
            "signal_action": a["signal_action"],
            "action_taken": a["action_taken"],
            "recommended_price": float(a["recommended_price"]) if a["recommended_price"] else None,
            "actual_price": float(a["actual_price"]) if a["actual_price"] else None,
            "quantity": a["quantity"],
            "score": a["score"],
            "regime": a["regime"],
            "notes": a["notes"],
            "recorded_at": str(a["recorded_at"]),
        }
        for a in actions
    ]
