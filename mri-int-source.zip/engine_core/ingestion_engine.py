import logging
import yfinance as yf
import pandas as pd
from concurrent.futures import ThreadPoolExecutor
from engine_core.db import get_connection, insert_index_prices, initialize_core_schema_v100

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def load_indices():
    """Ingest Index Data (v100.4)."""
    logger.info("📡 [engine_core] Ingesting Index Data...")
    initialize_core_schema_v100()
    tickers = ["^NSEI", "^BSESN"]
    for ticker in tickers:
        try:
            df = yf.download(ticker, period="300d", auto_adjust=True, progress=False).reset_index()
            # Robust flattening for yfinance multi-index
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = [
                    c[0] if (isinstance(c, tuple) and c[0]) else (c[1] if isinstance(c, tuple) else c) 
                    for c in df.columns
                ]
            df.columns = [str(c).lower().replace(" ", "_").strip() for c in df.columns]
            # Ensure 'date' column exists even if named 'index' or 'level_0'
            if 'date' not in df.columns and 'index' in df.columns:
                df = df.rename(columns={'index': 'date'})
            # yfinance sometimes emits duplicate column names (e.g., adj close). Deduplicate to avoid pandas warning.
            df = df.loc[:, ~df.columns.duplicated()]
            # Flexible column mapping to handle yfinance variations
            col_map = {
                'date': 'date', 'close': 'close', 'adj_close': 'close', 
                'open': 'open', 'high': 'high', 'low': 'low', 'volume': 'volume'
            }
            final_df = pd.DataFrame()
            final_df['symbol'] = ['NIFTY50' if ticker == "^NSEI" else 'SENSEX'] * len(df)
            
            for src, dest in col_map.items():
                if src in df.columns:
                    final_df[dest] = df[src]
            
            # Fill missing prices with available close price
            for p in ['open', 'high', 'low']:
                if p in final_df.columns:
                    final_df[p] = final_df[p].fillna(final_df['close'])
            
            final_df['volume'] = final_df.get('volume', 0).fillna(0)
            records = final_df.dropna(subset=['date', 'close']).to_dict('records')
            
            if not records:
                logger.error(f"  ❌ {ticker}: Produced 0 records after filtering. Check columns: {df.columns.tolist()}")
            else:
                insert_index_prices(records)
                logger.info(f"  ✅ {final_df['symbol'].iloc[0]} synced ({len(records)} rows).")
        except Exception as e:
            logger.error(f"  ❌ {ticker} failed: {e}")

def validate_data(symbol, df):
    """
    Sanity check for Yahoo Finance data.
    Returns (is_valid, reason)
    """
    if df.empty:
        return False, "Empty DataFrame"
    
    # 1. Check for missing critical columns
    required = ['open', 'high', 'low', 'close', 'volume']
    for col in required:
        if col not in df.columns:
            return False, f"Missing column: {col}"
            
    # 2. Check for zero or negative prices
    if (df['close'] <= 0).any():
        return False, "Detected zero or negative close prices"
        
    # 3. Check for impossible price spikes (>50% in one day for non-penny stocks)
    if len(df) > 1:
        pct_change = df['close'].pct_change().abs()
        # If price > 50 and change > 50% in one day, it's likely a data error or split not handled
        if ((df['close'] > 50) & (pct_change > 0.50)).any():
            return False, "Detected suspicious >50% price spike"
            
    return True, "OK"

def load_stocks(symbols):
    """Full Stock Ingestion for CSV list (v100.4)."""
    if not symbols: return
    logger.info(f"📡 [engine_core] Processing {len(symbols)} stocks (CSV list)...")
    
    def fetch_stock(symbol):
        try:
            # Suffix handle for NSE
            ticker = symbol if symbol.endswith(".NS") or symbol.endswith(".BO") or "^" in symbol else f"{symbol}.NS"
            df = yf.download(ticker, period="300d", auto_adjust=True, progress=False).reset_index()
            
            # Normalize columns first
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = [
                    c[0] if (isinstance(c, tuple) and c[0]) else (c[1] if isinstance(c, tuple) else c) 
                    for c in df.columns
                ]
            df.columns = [str(c).lower().replace(" ", "_").strip() for c in df.columns]
            if 'date' not in df.columns and 'index' in df.columns:
                df = df.rename(columns={'index': 'date'})
            df = df.loc[:, ~df.columns.duplicated()]

            # AUDIT: Validate before processing
            is_valid, reason = validate_data(symbol, df)
            if not is_valid:
                logger.warning(f"  ⚠️ {symbol} rejected by Audit: {reason}")
                return False
            
            df['symbol'] = symbol
            
            # Ensure missing data doesn't drop the whole row
            df['volume'] = df.get('volume', 0).fillna(0)
            for col in ['open', 'high', 'low']:
                if col in df.columns:
                    df[col] = df[col].fillna(df['close'])

            records = df[['symbol', 'date', 'open', 'high', 'low', 'close', 'volume']].dropna(subset=['date', 'close']).to_dict('records')
            
            # Use dedicated stock insertion
            conn = get_connection()
            with conn.cursor() as cur:
                # Target 'daily_prices' as per original schema
                from psycopg2.extras import execute_batch
                execute_batch(cur, "INSERT INTO daily_prices (symbol, date, open, high, low, close, volume) VALUES (%(symbol)s, %(date)s, %(open)s, %(high)s, %(low)s, %(close)s, %(volume)s) ON CONFLICT (symbol, date) DO NOTHING;", records)
                conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"  ❌ {symbol} failed: {e}")
            return False

    with ThreadPoolExecutor(max_workers=5) as executor:
        results = list(executor.map(fetch_stock, symbols))
    
    success_count = sum(results)
    logger.info(f"✅ CSV Ingestion Complete: {success_count}/{len(symbols)} symbols synced.")
