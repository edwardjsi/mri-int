SEC/SE/018/2026-27
Chennai, May 22, 2026

To
National Stock Exchange of India Limited
Exchange Plaza, Bandra Kurla Complex,
Bandra(E),
Mumbai – 400051
NSE Symbol - DATAPATTNS

To
BSE Limited
25th Floor, P.J. Towers,
Dalal Street,
Mumbai – 400 001
Company Code: 543428

Sub: Disclosure under Regulation 30 of SEBI (Listing Obligations and Disclosure Requirements) Regulations,

2015 – Transcript of Earnings Conference Call

Dear Sir/ Madam,

Further  to our earlier  letter  no.  SEC/SE/010/2026-27  dated  May  12,  2026  intimating  the  schedule of  Earning
Conference call on the financial results for the quarter  and year ended March 31, 2026, please find enclosed
herewith the transcript of the Earnings Conference Call held on Friday, May 15, 2026 at 10:30 A.M. IST.

The transcript of the earnings call is also available on the website of the company.

We request you to take the above record and oblige.

Thanking You.

For Data Patterns (India) Limited

Prakash R
Company Secretary and Compliance Officer
Membership No. F13620

Encl: As above

“Data Patterns (India) Limited

Q4 FY26 Earnings Conference Call”

May 15, 2026

MANAGEMENT:  MR. S. RANGARAJAN – CHAIRMAN & MANAGING

DIRECTOR – DATA PATTERNS (INDIA) LIMITED
MR. VENKATA SUBRAMANIAN – CHIEF FINANCIAL
OFFICER – DATA PATTERNS (INDIA) LIMITED

MODERATOR:  MS. PRAYASI PATEL – GO INDIA ADVISORS

Page 1 of 20

Moderator:

Ladies  and  gentlemen,  good  day,  and  welcome  to  Data  Patterns  (India)  Limited  Q4  FY26

Data Patterns (India ) Limited
May 15, 2026

Earnings Conference Call hosted by Go India Advisors LLP. As a reminder, all participant lines

will be in the listen-only mode and there will be an opportunity for you to ask questions after

the presentation concludes. Should you need assistance during the conference call, please signal

an operator by pressing star then zero on your touchtone phone. Please note that this conference

is being recorded.

I now hand the conference over to Ms. Prayasi Patel from Go India Advisors. Thank you, and

over to you, ma'am.

Prayasi Patel:

Thank  you.  Good  morning,  everyone,  and  welcome  to  Data  Patterns  (India)  Limited  call  to

discuss the quarter four and FY26 earnings call. We have the senior management of the company

on call Mr. S. Rangarajan, Chairman and Managing Director; and Mr. Venkata Subramanian,

Chief Financial Officer.

We  must remind you that the discussion on today's call  may include certain forward-looking

statements and must be therefore viewed in conjunction with the risks that the company may

face. May I now request Mr. Rangarajan sir to take us through the company's business outlook

and financial highlights, subsequent to which we will open the floor for Q&A. Thank you, and

over to you, sir.

S. Rangarajan:

Thank you, Prayasi. Good morning, ladies and gentlemen, and a very warm welcome to all of

you to the quarter four and full year FY26 Earnings Call of Data Patterns (India) Limited. We

sincerely appreciate your continued trust, support and participation. I hope all of you had the

opportunity  to  review  our  earnings  presentation,  which  has  been  uploaded  on  the  Stock

Exchanges and our company website.

Before Venkat takes you through the financial performance in detail, I would like to briefly share

some key business and operational highlights for the year. FY26 has been a significant year for

Data  Patterns,  marked  by  strong  execution,  healthy  order  inflows,  continued  capability

expansion and increasing participation across strategic indigenous defence programs.

During  the  year,  we  continue  to  strengthen  our  position  across  radars,  electronic  warfare

systems, avionics, communication systems and strategic defence electronics, supported by our

strong in-house design and engineering capabilities built over nearly 3 decades.

One  of  the  key  highlights  of  the  year  has  been  a  strong  momentum  in  order  inflows,  during

FY26, the company recorded order inflows of approximately INR1,121 crores, increase of 216%

year-on-year, reflecting healthy demand across multiple defence and aerospace programs. The

order inflows were well diversified across radar systems, avionics, electronic warfare, services

and  strategic  electronics  applications,  demonstrating  increasing  customer  confidence  in  our

technological capabilities and execution track record.

The order book as on date stands at approximately INR2,062 crores, including orders negotiated,

which provides a strong revenue visibility over the coming years. In addition, we continue to

see a healthy pipeline of opportunities across radar systems, electronic warfare and advanced

Page 2 of 20

Data Patterns (India ) Limited
May 15, 2026

defence  electronics.  Other  than  the  order  book,  additional  single  vendor  contracts  based  on

already supplied products, which can fructify into contract this financial year stands at INR1,900

crores.

Further, based on previous delivery and performance of strategic system supplies, our customers

would  like  to  place  further  contracts  on  such  programs  leading  to  significant  order  book

accretion, we should get visibility for these contracts, including timelines during the year.

Our  earlier  investments  made  towards  realizing  EW  suites,  including  self-protection  Jammer

Pods for Indian fighter aircrafts have been well received by IAF, and we are poised to take the

next steps for flight testing. This will lead to revenue during the medium term. The opportunities

being addressed by Data Patterns with in-house developed large systems already delivered to

customers  has  immediate  requirement  to  address  strategic  space-based  surveillance  and

mitigation, allowing Data Patterns to substantially increase revenue in the coming years towards

building an order book of at least 3 years revenue, ensuring predictable growth.

We are entering into an exciting phase in India with the defence and aerospace industry set to

grow substantially to reduce reliance on imports, especially in this geopolitical situation. Further,

with  the  advance  of  AI  in  all  phases  of  our  business,  Data  Patterns  has  leapfrogged  into

absorption of AI for processes as well as technology and products.

This  will  allow  Data  Patterns  to  introduce  new  world-class  products  quickly  to  address  the

awning gap on Indian capabilities and products, necessitating imports and reliance on foreign

OEMs  to  meet  our  critical  defence  needs.  We've  also  repositioned  some  of  our  products  to

address the growing requirement of drone detection, spoofing and jamming with both radars and

ESM products.

These are in advanced stage of development and expect to bring in additional revenue in the

medium term. We are investing in expanding our product development across radars for airborne

platforms, including surveillance and fire control, including maritime applications, which were

hitherto the domain of Indian development agencies and foreign OEMs. We expect these to bring

in revenue over the next few years and also allow exports of complete products.

Our export business also continued to progress steadily during the year. The export order book

as on date stands at approximately INR53 crores, and exports remain an important strategic pillar

of our long-term growth road map. We are actively engaging with customers in Europe and other

international  markets  while  strengthening  our  export-oriented  marketing  and  business

development initiatives.

We continue to execute repeat business from U.K. and expect export momentum to improve

meaningfully as our complete system capabilities mature further. We believe that our revenue

from  exports  will  increase  starting  this  year  as  most  countries  are  increasing  their  spend  on

defence given the present geopolitical situation. We believe that the products and capabilities

offered  by  Data  Patterns  will  allow  even  Western  countries  to  procure  from  Data  Patterns,

Page 3 of 20

Data Patterns (India ) Limited
May 15, 2026

leveraging  our  capabilities  and  much  shorter  time  frames,  delivery  time  frames  meeting  the

requirement.

During  the  year  24  -  25,  we  also  achieved  an  important  milestone  with  the  successful

development  and  export  of  Transportable  Precision  Approach  Radars  to  European  country,

including successful site acceptance testing. This reflects not only our technology capabilities,

but  also  the  growing  acceptance  of  Indian  defence  systems  and  engineering  expertise  in

international  markets.  We're  also  getting  additional  inquiries  for  these  products  from  various

countries.

We believe the global defence industry is entering a multi-decade investment cycle driven by

rising geopolitical uncertainties, accelerated modernization programs and increasing focus on

self-reliance in defence manufacturing. Advanced electronics, radar systems, electronic warfare

and intelligent surveillance capabilities are becoming central to modern defence preparedness

globally.

This creates a significant long-term opportunity for India's indigenous defence ecosystem with

a strong in-house design capabilities, advanced engineering expertise and proven execution track

record, Data Patterns is well positioned to capitalize on this opportunity.

Coming  to  our  financial  performance.  FY26  has  been  another  strong  year  for  the  company.

Revenue of FY26 grew by 31% year-on-year to INR925 crores, while EBITDA increased by

35% year-on-year to INR371 crores. Looking ahead, the outlook for the Indian defence sector

remains extremely strong. We remain committed to delivering sustainable and profitable growth

while continuing to invest in future technologies, strengthening our complete systems portfolio

and maintaining a strong balance sheet.

We continue to target revenue growth of around 20%, 25% over the short term while maintaining

healthy EBITDA margins of 38% to 40% and preserving our net cash status. Most importantly,

beyond  financial  performance,  we  remain  deeply  committed  to  contribute  towards  India's

journey of technological self-reliance and strategic defence capability development.

With that, I would now like to hand over the floor to our CFO, Mr. Venkata Subramanian, to

take you through the financial performance in greater detail.

Venkata Subramanian:

Thank you, sir. Good morning, ladies and gentlemen, and thank you all for joining us today. We

are  pleased  to  report  another  strong  year  of  operational  and  financial  performance  for  Data

Patterns. FY26 reflects the continued strength of our execution capabilities, resilient business

model and increasing demand across strategic defence and aerospace programs.

Let me take you through the key financial highlights for the quarter and full year  FY25 - 26.

Revenue from operations for FY26 stood at INR925 crores as compared to INR708 crores in

FY25, registering a healthy growth of 31% year-on-year. Gross profit for the year increased by

35% year-on-year to INR585 crores due to increase in revenue and favorable product mix, while

gross margins improved to 63 percentage compared to 61 percentage in FY25.

Page 4 of 20

Data Patterns (India ) Limited
May 15, 2026

EBITDA  for  FY26  stood  at  INR371  crores  as  against  INR275  crores  in  the  previous  year,

reflecting  a  growth  of  35%  year-on-year.  EBITDA  margins  improved  to  40%  supported  by

operational efficiencies and improved absorption of the fixed costs. Profit after tax for  FY26

stood at INR271 crores, registering a growth of 22% year-on-year, while PAT margin remains

healthy at 29%.

Coming to the quarterly performance, Q4 '26 revenue stood at INR345 crores, while the revenue

was lower by minus 13% year-on-year due to timing of execution of certain programs, revenue

nearly doubled sequentially with a growth of 99 percentage quarter-on-quarter, reflecting strong

execution momentum during the quarter.

Pertinent to also note that share of fourth quarter revenue was 37% in FY26 as against 55% in

FY25. Gross margin for Q4 FY26 improved significantly to 73% as compared to 49% in Q4 of

last year. EBITDA for the quarter stood at INR193 crores with EBITDA margins at 56%, while

PAT for the quarter stood at INR139 crores with PAT margin of 40 percentage.

From a working capital perspective, we continue to see improvement in operational efficiency

during FY26. Our cash conversion cycle improved meaningfully to 365 days in FY26 from 428

days in FY25, reflecting strong execution, better inventory management and continuous focus

on disciplined working capital control.

As  of  March  2026,  our  order  book  stood  at  approximately  INR926  crores  while  including

negotiated and expected orders, the order book pipeline remained strong at around  INR2,062

crores. Our order book continues to remain diversified across radar systems, avionics, electronic

warfare, communication systems and strategic electronic applications.

The company continues to maintain a strong balance sheet and remains a debt-free company.

We believe our healthy liquidity position and disciplined capital allocation strategy provides us

with  the  flexibility  to  continue  investing  in  R&D,  infrastructure,  advanced  technologies  and

manufacturing capabilities.

Going  forward,  we  remain  optimistic  about  the  long-term  opportunities  in  the  domestic  and

international  defence  sector  and  continue  to  focus  on  execution,  operational  efficiency,

technology development and profitable growth.

With that, we would like to open the floor for questions and answers. Thank you.

Moderator:

We will take our first question from the line of Dipen Vakil from Phillip Capital India.

Dipen Vakil:

Congratulations on a great EBITDA margin and surpassing the revenue and guidance for the

year. Sir, my first question is on the lines of your margin profile itself. So, you have told us that

you  have  told  --  so  this  quarter,  you  had  some  great  EBITDA  margin,  so  can  you  help  us

understand as to what is the -- which product mix has led to such strong EBITDA margin and

out of those order book, what kind of EBITDA margins can we expect going ahead?

Page 5 of 20

S. Rangarajan:

You see we have a differentiated product line. The margins for Q2 were much lesser because,

Data Patterns (India ) Limited
May 15, 2026

as I earlier explained in the call also, there is a strategic program where we've taken a contract

at a lower cost and  lower  margin, but it's  helped us built us a capability to build a complete

system  and  also  the  program  management  office,  which  is  necessary  other  than  also

demonstrating mechanical capabilities, which is not when we talk about an electronics company.

So, these are the takeaways from this contract and also our commitment that this will also lead

to future contracts.

So, we take some contracts with lower margin consciously to ensure that we build our capability,

product capability and also give you -- allows us future expansion. So that is the reason last year

quarter, quarter-to-quarter differences were there. And though there's an increase in revenue in

quarter two and overall revenue has been as per guidance, slightly better than guidance. And the

rest  of  the  margin  which  you  talk  about  is  that  is  normally  where  our  complete  product

development is done in-house. Where all the IP is created in-house, we don't import anything

and integrate.

So, this is in nature of exactly what we normally do. And since there is no bought-out in those

last quarter revenue. And it is all our own full systems, which has been developed by us was

sold,  the  margin  profile  was  different.  So,  you  need  to  look  at  not  --  you  can't  give  a  direct

guidance on contract to contract, how it will go in terms of EBITDA or margin because this is

the overall business cycle.

There are many many products, and we take some products at different kinds of pricing based

on our, one, ability to absorb it, two, to see how the future business is going to look at and the

business prospects we take a call on that and take a decision where to make an offer, how to

quote it.

This is what we have done. And now that the opportunities are much larger and becoming much,

much  larger,  we  need  to  build  a  capability  upgrade  in  our  company  to  address  larger

opportunities going forward. I think I've answered your question. Is there anything else, please

ask again?

Dipen Vakil:

Yes, sir. Sir, that was very much clear. So just another thing on that. So, you mentioned that you

have currently INR2,000 crores of order book of which roughly INR1,000 crores already in the

books  and  INR1,000  crores  expected.  So,  any  time  line  on  that  as  to  when  we  can  expect

finalization of those INR1,000 crores where negotiations are completed?

S. Rangarajan:

I think in the next 1 to 2 months' time,  we should expect the contracts to happen. Unless, of

course, there is some -- see these are all government customers. So, I can't predict for them. But

our feeling is that it should happen in the next 1 to 2 months time.

Dipen Vakil:

And over and above that, we are expecting orders to the tune of INR15 billion to INR20 billion

for FY27?

S. Rangarajan:

Yes. See, what has happened is we have developed products earlier. And those products during

the course of this year will have repeat orders. So that has been for INR1,900 crores. So these

Page 6 of 20

Data Patterns (India ) Limited
May 15, 2026

are all single tender orders just expected during the course of the year. The timing is not exactly

visible. That is why I said during the course of the next 12 months, we should get additional

order  book,  which  is  based  on  already  developed  products  and  delivered  and  accepted  by

customers.

And repeat requirements are already quoted for in some situations and inquiries have also come

in for another. Wherever we're talking about INR1,900 crores, we've already quoted for those

requirements. The only thing is some of the negotiations may have to happen and the time lines

are not exactly in our control. But it should happen during the course of the year.

Dipen Vakil:

Got it, sir. Got it. Sir, last question on the production. So in this order inflow, what will be the

proportion of the production order inflow, which are expected to be like a short-cycle orders. So

any indication on those that out of those INR2,000 crores or maybe INR1,000 crores, how much

will be the quantum of the production orders?

S. Rangarajan:

I can't give you exact ratio now. What has already delivered, I said we get the repeat order of

INR1,900 crores, that will all be production orders because already we've done the development.

On the existing INR2,000 crores, some are service orders, some are already developed orders

and some are new development, which is going to take place.

And so I don't have the exact mix and percentages. But whatever we have taken up, even for

development initiatives we're taking up, they're looking at it only with the perspective of future

requirements  are  there  for  such  products  and  programs.  So  whatever  we  develop,  we've

developed with building blocks and they have a future requirement in other applications as well.

So that is how the development cycle is actually managed by the company. So I can't give you

exact number, but there will be a larger size production contracts for the overall business we

expect as we go along.

Moderator:

Next question is from the line of Rishika from Goldman Sachs.

Rishika:

Sir, I have  two questions. You indicated that you're working  with global OEMs.  I wanted to

understand what's the traction around that? And if you have anything apart from U.K. Secondly,

when can we expect to get the order for BrahMos seeker? Certain media articles indicate that

the production is hampered. Will it have a material impact on our revenue growth in FY27?

S. Rangarajan:

Okay.  First  question  is  global  OEMs.  A  number  of  them  have  started  visiting  us  and  quite

impressed  with  whatever  we've  achieved  in  terms  of  capabilities  and  products.  So  similar

products are required in Europe. So, the inquiries have started coming from Europe for building

such products, and they quite like our prices and delivery term.

I think in the next 2, 3 months' time or 4 months' time, we should start getting some contracts

from these global OEMs, which will lead into some development initiatives initially, but then

which will lead to year-on-year or quarter-to-quarter delivery for their actual military programs

for which they are addressing their opportunities.

Page 7 of 20

Data Patterns (India ) Limited
May 15, 2026

So, this is going to be not a one-off system, but there will be multiple systems based on what we

already developed and modified to meet their OEM requirements. So, this is one part of the story

on exports is concerned. We also want to now expand our own export team, build a team to

address exports because we believe that there is going to be increased look at India with our

capabilities and delivery models, which Europe and U.S. and other countries would be looking

at very seriously. So, I think this is a growing business.

And since we have done a lot of product development in-house, which matches the requirement

immediately, I think there will be a lot of traction once we put the marketing team to address the

opportunities.

So, we are going not just U.K., but other than U.K. also in Europe, inquiries have started coming

in. Other people who are visiting us are also from U.S. from civil aviation and things like that,

people have  started  visiting  us  and quite  taken  interest  in  our  capabilities  and  inquiries have

started coming in.

Regarding BrahMos seekers, the first variant of the development seeker order is under execution.

Once  there  the  execution  is  completed,  I  think  in  the  next  4,  5 months'  time,  the  production

orders  would  start  coming  in.  They've  indicated  production  orders,  and  they  want  it  to  be

delivered before next year, middle is what the customer is saying. So I don't think there is going

to be any distress on delivery time lines as far as BrahMos is concerned with our kind of seekers

and systems.

Whatever orders was given in 3, 4 months back in BrahMos seeker, we've already delivered.

And by March, we delivered it. So our time lines for delivery is quite fast with respect to other

competitors, which are there in this line of business. So I don't think we'll have a problem in

terms of revenue.

And anyway, this is part of the expected order of INR1,900 crores is what we have projected,

not in  the  orders  on hand  situation.  So,  I don't  think  there  will  be  a  revenue  offset  based  on

BrahMos even if there's a delay. But I don't think there's going to be a delay.

Moderator:

Next question is from the line of Hardik Rawat from IIFL Capital.

Hardik Rawat:

Congratulations team on a wonderful result. Sir, my first question would be with regards to the

current order book. So, we have some INR1,000-odd crores of order book, and we expect another

INR1,000-odd crores of negotiated orders to flow through in the coming month or 2?

Just wanted to understand, our order book mix, if I look at today, the share of services and that

is roughly  INR350-odd crores, the order book as at the end of 4Q. When  you talk about the

negotiated orders, could you give us an indication as to what part of this would pertain to services

or/and what part would pertain to products?

Venkata Subramanian:

I think about on this  INR1,000-odd crores, which I've said  maybe  INR100 crores will be on

services, so the rest on product delivery.

Page 8 of 20

Data Patterns (India ) Limited
May 15, 2026

Hardik Rawat:

Got it. So that would mean that in the next 2 months, we'll be sitting on a product order book of

about -- we should be sitting, again, not -- understanding that the orders can be delayed. But our

expectation is that we should be sitting at a product order book of about INR1,500-odd crores.

Would that be correct? INR575 crores that you already have and some INR900-odd crores that

you'll be getting?

Management:

Yes, around that or even slightly higher.

Hardik Rawat:

So now I want to understand since a large part of our product portfolio and because of our faster

execution time line, the execution has largely been short cycle. What do you expect the execution

cycle to be on this INR1,500 crores of orders that you'll be sitting at in the month of it?

S. Rangarajan:

That is not whether we can execute or not. It depends on the program requirements. Some of the

program requirements are spread over 3 years delivery. Some is delivered in a few months. So

that  varies  from  the  contract  to  contract.  And  that  will  be  mostly  based  on  customer

requirements, not on our ability to deliver.

Hardik Rawat:

No, sir, I get that. What I'm trying to understand is that based on the delivery schedules that you

have, what is your expectation in terms of order execution cycle, if you can break it down and

what do you expect, again, we're not holding you to this, but what do you expect...

S. Rangarajan:

We have projected about 20%, 25% revenue growth. We won't think we have a problem on those

things. So that will happen. And if the other INR1,900 crores things come in early, some part of

it can be executed this year also. And that will also bump up our revenue model. So since we

don't  have  the  exact  timing,  we  have  only  projected  this  20%,  25%  growth.  But  once  the

contracts  are  at  hand,  we  already  developed  these  products,  our  execution  time  lines  can  be

matching customer requirements or even earlier.

So, depending on that, the delivery model will happen. So, at the present moment, we don't want

to wage any kind of saying that we will do this way because we know we are confident of doing

this.  But  this  is  a  base  point.  I  think  as  the  contracts  start  coming  in,  larger  contracts,  our

projections may vary from quarter-to-quarter.

Hardik Rawat:

Got it. That's very helpful. the point was...

Moderator:

I'm sorry to interrupt. Hardik, you may please rejoin the queue for more question. We will take

our next question from the line of Riya Bhatia from PNB.

Riya Bhatia:

Yes.  So  I  just  wanted  to  understand  about  the  order  inflow  for  the  year.  You  said  around

INR1,500  crores  to  INR2,000  crores.  This  is  apart  from  the  INR1,100  crores  that  has  been

negotiated, right?

S. Rangarajan:

Yes.

Riya Bhatia:

Okay. So then would it be correct to assume that you'll be ending the year with around INR3,500

crores to INR4,000 crores of order book?

Page 9 of 20

Data Patterns (India ) Limited
May 15, 2026

Management:

No. We will also be executing contracts, which is coming in.

Riya Bhatia:

So, what will be the order book for the year?

S. Rangarajan:

I  think  it's  a  bit  early  for  that.  We  will  come  towards  the  year-end  before  we  give  you  the

numbers. It's a bit early because there are a lot of programs we're working on. Some of the large

contracts and strategic programs also the order may start coming in. If the order starts coming

in, the order book size will grow, plus the export revenue, which is going to happen. So, there

are so many areas of product development, and we are making offers to customers.

So, if we're successful, we will be able to have a very healthy order book going ahead. That is

why in the opening remarks, I mentioned that this is the first time I've given an all-rounded view

on the market and where we are in terms of investment models and product models and how the

business is supposed to scale in the coming -- in the short and medium term.

I've given you overall perspective on repeat business from existing deliveries, new things which

can happen and then other areas where we are focusing on product development also, plus the

export and the repeat business is expected.  So, we've also said that if  some of this, what  we

predicted it happens, we'll have a healthy product order book, which will also give us a clarity

of quarter-to-quarter growth over the next 2 to 3 years' time, while we still strive for building

larger businesses going ahead.

So, I think we have a fairly rounded view I've given on the opening remarks. So -- but to exactly

tell you end of March, what will it be, I think towards Q2, Q3, depending on how we get the

orders going ahead, that will give you a better answer.

Moderator:

Next question is from the line of Akshay from AK Investment.

Akshay:

My one question is already answered, and congratulations on the great set of numbers. And sir,

my  second  question  is how  much  cash  flow  from  EBITDA  are  you  expecting  to  generate  in

FY27 and going forward for the next 2 to 3 years? Because for the last 2 years, our cash flow

generation from operations has been very weak.

S. Rangarajan:

No, I didn't understand the question. What is that? What did you ask?

Akshay:

Sir,  I  am  asking  about  the  cash  flow  from  operations  since  last  2  years,  our  cash  flow  from

operations has been very weak, so over the next 2 to 3 years -- cash from operating, sir?

S. Rangarajan:

So cash flow from operations, okay.

Akshay:

Yes. So over the next 2 to 3 years, how much conversion from EBITDA are we expecting?

S. Rangarajan:

I don't know. Venkat, do you want to answer this question?

Venkata Subramanian:

The cash conversion cycle today is at 365 days. We are seeing improvements year-on-year. We

expect it to probably settle down at 320 to 340 days going forward. But year-on-year, we cannot

Page 10 of 20

Data Patterns (India ) Limited
May 15, 2026

-- at the beginning of the year, it's very early to calculate all that and come out with an answer

for this.

But  we  are  definitely  focusing  on  reducing  the  working  cycles,  and  it  is  also  showing  some

improvements year-on-year. So going by that, we expect it to settle down at 340 to  -- I mean

320 to 340 days going forward. But probably during the middle of the year, we can take a review

on this. And some color can be given, but this is too early now.

Moderator:

Next question is from the line of Pujan Shah from Molecule Ventures.

Pujan Shah:

Sir, first question pertains to  -- in the last, our con call, you have said that we might receive

INR1,100 crores in 1 to 2 months' time line, while that has been delayed. But while I was also

reading some of the tender participation and where we can be -- I would think that there is also

an order of INR1,007 crores for Tejas Mk1A, is it possible -- is it the same order...

S. Rangarajan:

What is that order? INR1,007 crores. What is that?

Pujan Shah:

INR1,007 crores order value for Tejas Mk1A.

S. Rangarajan:

Tejas, okay.

Pujan Shah:

So, is it the same order, which I'm being considering or you're being considering in the last con

call? Or it is just different order all together?

S. Rangarajan:

These are not Tejas one. Tejas one is part of -- some inquiries have come, we quoted for whatever

products are going, avionics is going into Tejas. So this  -- hopefully, the orders should come

during the course of this year. It normally goes through a really large negotiation cycle  with

HAL.

So, we have to wait and watch when the order is placed. But I've not projected anything last year

for Tejas. We had orders in hand, which we executed but the new order projections is this year

only, we're talking about other, than that order-on-hand situation, already delivered products,

which repeat orders may happen. For this, we've already quoted. And Tejas also, we already

quoted. So we have to see when the contract comes. It will be only this year.

Pujan Shah:

Okay. But sir, I just want to try, sir, because the tender was closed on, I think, 13th or 23rd of

March. I don't remember the exact date. And in 65 days of time line, it needs to be concluded on

their side. So there is no update from -- on the portal or something like that. So how should...

S. Rangarajan:

I don't know which you're talking about. I'm not aware of what you're talking about. So I won't

be able to comment on it.

Venkata Subramanian:

And to give you more clarity, actually, the orders negotiated of INR1,000-odd crores, which was

shown in the previous conference call, is not a single case, it's multiple cases. Some of them we

have got the contract. And that number now stands at INR1,090 crores. I mean we have got some

more contracts negotiated in between last conference call and now. So put together INR1,090

Page 11 of 20

Data Patterns (India ) Limited
May 15, 2026

crores as on date as we speak. So including that, our order book today stands at INR2,000 crores

plus, INR2,062 crores to be precise.

S. Rangarajan:

You'll have to wait for Tejas order to happen, and we'll announce it to the market as and when

the order happens.

Moderator:

From the line of Garvit Goyal from Serene Alpha.

Garvit Goyal:

Congrats for good numbers. Sir, in your opening remarks, you mentioned about some delays of

certain programs. Can I know what kind of programs are these? And secondly, if these delays

and these programs are getting deferred to  FY27, then fundamentally, your growth should be

more than 25%. And why we are speaking about 20%, 25%. So that's my first question.

S. Rangarajan:

No, I never -- what are these 13 programs? I don't know what you are talking. It's 13 programs?

Garvit Goyal:

Not 13. I'm saying you mentioned about some programs getting delayed in execution in Q4 that

will be deferred in next year. That's what you said, right?

S. Rangarajan:

No, no, no, I never mentioned. I never said anything like that. I never said anything like that.

I've only compared quarter 2 to quarter 4 performances. And then there are expected orders from

what we delivered in quarter 2, but I never talked about any delays. I've only talked about orders,

which is expected, let's say, another INR1,900 crores for repeat contracts.

I'm not able to give you time lines on those orders because these are all government contracts.

But I expect this to happen over the course of this year is what I said, I never talked about delays

on any other thing.

Garvit Goyal:

Okay. So, if I look at the execution in Q4, it is falling behind Q4 last year, right? So we were

having the order book in our hand, right? So what is stopping us in executing those contracts?

Like what is the reason behind the poor execution?

S. Rangarajan:

There's not a poor execution. Actually execution has been actually very good. It's not poor. It is

a good execution. And the execution has to be in line with customer requirements. I may have

an order on hand, but customer doesn't want delivery today. There may be preconditions to our

delivery. So based on customer request, we deliver and based on the contract. So execution has

not been poor. Actually, execution is very good. We delivered things in 2 months and 3 months,

which is very, very good.

And our Board is very happy with the execution and how we manage the execution. So there is

no delay  from our side. It's a question of the agencies, government agencies getting together

approval,  these  kind  of  things  normally  go  through  a  process  and  that  process  delay  is  not

addressed by -- we can't address those process delays. But we've never had an execution delay

from our office.

Moderator:

We will take our next question from the line of Shrinarayan Mishra from Baroda BNP Paribas.

Page 12 of 20

Data Patterns (India ) Limited
May 15, 2026

Shrinarayan Mishra:

Sir, my first question is on the largest order that we have received in Q4, IMD radar development

and service order. What would be the execution cycle for that order?

S. Rangarajan:

The requirement is between over 18 months. We're trying to see how fast we can deliver it.

Shrinarayan Mishra:

Okay. And sir, since I can see in the order backlog, our services mix has increased significantly.

So would that mean trade receivable days would improve? Or how should we see that?

S. Rangarajan:

No, no. You're talking about services?

Shrinarayan Mishra:

Yes. In the order book services mix has increased.

S. Rangarajan:

Trade receivables will not increase because we don't bill for services until the services are carried

out. The only product delivery happens, we bill only product development. The services part of

the contract, we will bill as and when the services happen and delivery of the services happen.

So there are 2 independent parts to the order. So we will not bill the overall amount and wait for

services to happen over the next 4, 5 years. That is not the way revenue recognition is done. It's

not done that way.

Venkata Subramanian:

Service orders represent our AMC revenue. AMC is actually for multiple years. It's not a single

year AMC.

S. Rangarajan:

So there is a process for revenue recognition. There is a process in revenue recognition. This is

not add to any -- what -- receivables increase and all those things.

Shrinarayan Mishra:

So from the date of billing of a service order, how many days it takes to collect the amount?

S. Rangarajan:

It depends on the customer.

Venkata Subramanian:

It depends on the customer and the processes involved.

S. Rangarajan:

See, what we do is after the service, it again depends on the contract, when the billing can start,

so at the end of the service contract, 1 year over, the annual billing can be after end of the year

or if it is quarterly billing and quarterly -- so it depends on the contract, varies from contract to

contract. And the payment cycle terms varies from customer to customer.

Shrinarayan Mishra:

But in general, if you were to generalize, is it better than production orders or?

S. Rangarajan:

I can't generalize because uniquely government agencies are there. IMD is the first case, which

is taken up now. So, until we get some money transfer from IMD, we won't be able to generalize.

Moderator:

Next question is from the line of Amit Sharma, an Individual Investor.

Amit Sharma:

Congratulations on a great set of numbers. I have two specific questions, 1 related to our current

order book. So we have for 38% of our current order book coming from services, which has

Page 13 of 20

Data Patterns (India ) Limited
May 15, 2026

roughly an elongated execution cycle. So does that -- and even in our negotiation order book of

INR1,090 crores, even that also we have a sizable amount coming from services.

So, does that put a pressure for us in terms of our growth size? Would our growth will be, say,

25% growth, would that be a pressure point for us for the coming year as well as for next year

FY28?

S. Rangarajan:

Okay.  This  question  has  already  been  asked  and  answered.  INR1,090  crores  I  gave

approximately about INR100 crores to be services. The rest is product delivery. So it will not

affect the -- our top line revenue growth is what we projected, I said 20%, 25%. We believe we

should be able to do this. On top of why we said we should be this is also that there are a number

of repeat contracts we're expecting during the course of the year.

So  it  happens  early,  then  we  can  deliver  those  products  earlier.  So  that  also  will  bring  in

additional  revenue  or  either  part  of  the  revenue  projections  or  over  and  above  the  revenue

projections, we can do that. So it depends how the order inflow happens during the course of

this year.

Amit Sharma:

But basically,  what  you are saying is that the quick execution order book like  we had in the

current year is what we are largely depending on for the -- to achieve the ballpark number that

we are guiding for the current year, in fact...

S. Rangarajan:

Yes,  we  believe  it  will  be  substantially  higher  than  the  guidance  number  is  what  we  expect

because I think a lot of long-term initiatives the company has taken. And I think those initiatives

one by one will start fructifying into contracts. Once it starts getting contracts, our order book

situation should grow substantively in the coming years is what we expect.

And we have developed products and over a period of time to ensure that this -- we can scale

the company very quickly into multiple thousand crore company rather than scale it 20% year-

on-year. That is not what we're looking at in the management cycle here. We're actually looking

at some very high scalability in the coming years. And the strategy and product development

mix is working towards how to build the scalability and sustainable scalability is what  we're

working on.

Moderator:

Next question is from the line of Sahil Karia from White Pine Investment.

Sahil Karia:

So apart from BrahMos missiles, which are the missile programs...

S. Rangarajan:

I can't hear you at all. I can't hear you at all. Can you come to nearer the phone and call.

Sahil Karia:

Am I audible?

S. Rangarajan:

Yes.

Sahil Karia:

So apart from BrahMos missiles, which are the missile programs...

Page 14 of 20

Data Patterns (India ) Limited
May 15, 2026

Moderator:

I'm sorry to interrupt, Sahil. Can you use your handset mode, please?

Sahil Karia:

Am I audible now?

Moderator:

Yes.

Sahil Karia:

Yes.  So  apart  from  BrahMos  missiles,  which  are  the  missile  programs  are  we  delivering

products, seekers and IR products to and all these products could we be the relevant vendors?

S. Rangarajan:

I'm still very confused with your question. You're not very audible.

Sahil Karia:

Apart from BrahMos missiles, which are the missile programs, are we delivering products  to

and for which product are we L1 vendors?

S. Rangarajan:

Other than BrahMos product, there's one other program for the air defence. We've done a seeker

that is under delivery  mode now. But there are no other programs on the missile area. We're

working  on  seekers.  But  as  a  concept,  we  want  to  take  up  initiatives  to  build other  kinds  of

seekers, electro optic, etcetera, seekers on our own. And where  we are positioning ourselves

with an industry partner to see that we can meet the revenue model as we go along.

But those are all development initiatives internal to office. But as of now, we don't have anything

else because we work on whatever DRDO allows us to do. We develop the products as per the

requirement. So until then, it will be now -- it's really controlled by DRDO or missile program

itself.

As  and  when  the  missile  program  becomes  opened  up,  other  agencies  start  building,  large

corporates start coming into the business, then maybe we should be able to do a large part of the

missile and have an ecosystem which will develop the system, but that's yet to happen.

Moderator:

We will take our next question from Jenish Karia from Union AMC.

Jenish Karia:

So, my question is on the AMCA program.  Any update on our consortium's position for the

AMCA program? And irrespective of the outcome of the -- which consortium is winning, what

would be our opportunity within the AMCA program?

S. Rangarajan:

Yes, AMCA program, the RFP is expected any time now. So that is the first status. Second is on

the AMCA, we've -- the glass cockpit is developed by us. The mission systems is developed by

us for the LCA-Mk2, which is going to be taken to AMCA. We are hoping that as we go along,

more such -- on the sensors and RWR and radar and things like that, as and when we are able to

develop products and it is acceptable to the customer.  All such programs  will  follow. At the

present moment, we have only the cockpit solutions and machine management system is being

done by us.

Moderator:

Next question is from the line of Santhosh from iThought PMS.

Page 15 of 20

Data Patterns (India ) Limited
May 15, 2026

Santhosh:

Okay. So, I just want to know like out of the negotiated orders of INR1,000 crores, you did say

that if the delivery schedules are okay, we might deliver some of those contracts this year. Would

that growth be over and above the guidance of 20%, 25% you are guiding for?

S. Rangarajan:

No, I never mentioned. I think you misheard me, you misunderstood the whole thing, which I've

answered.  I  never  said  the  INR1,000  crores,  we  only  talked  about  orders  on  hand,  expected

orders and negotiated with INR1,000 crores. I never said that this will be delivered earlier and

things like that. I talked about other INR1,900 crores.

If it were to come, similarly the business that happen during the course of the year, comes in

early, then I can include them early. That is what I talked about, not on the contracts on hand. I

didn't understand the second part of your question. What was the second part of the question?

Santhosh:

No, I'm just asking that if that INR1,000 crores, if the delivery schedule is allowing you to get

the revenue today, would that be over and above the guidance you're suggesting for? Because -

- is there any capacity constraint is my question as well?

S. Rangarajan:

No, we are building large capacities. For export contracts already capacity we have built, plus

we are building something about nine floor of factory space to build in additional capacity to see

that the larger -- as we -- the program size has increased and the volume of contracts increase to

scale to multi thousand crore company. We already started investing on capex and infrastructure

expansion because it takes 1 to 2 years' time. So, we're already in the process of doing it.

For seekers and other things, we already put the building blocks and infrastructure necessary to

ramp up production. Already, we have done that. So, I don't think we will have a problem in

execution. As and when it happens, we are aware of when this will happen. Of course, the time

lines are not very predictable. But -- so we have taken a cautious view of not overspending in

infrastructure and the contracts don't happen.

I don't want to sit on capex infrastructure there. So, this has to be judiciously implemented, but

we are aware that scaling is going to happen substantively.  And we are taking an aggressive

position on terms of capex infrastructure to address the scaling requirements as we go along.

Moderator:

Next question is from the line of Dipen Vakil from Phillip Capital India.

Dipen Vakil:

I wanted to understand on your product development and also on the Virupaksha -- component

for the Virupaksha Radar that you had supplied to Indian Air Force as well. So, any update on

that as to what is the progress? How was the response? And if there's any concrete order which

we can expect from there?

And you also mentioned about the new areas of development around anti-drone system, drone

detection. So, can you tell us about -- more about the time line as to when these products will

start getting commissioned or rather in that approval stages and we can expect some revenue

from them?

Page 16 of 20

S. Rangarajan:

Okay. First is Virupaksha is not our product. Virupaksha is a DRDO project, name for the Super

Data Patterns (India ) Limited
May 15, 2026

Sukhoi radars. This is not ours. We call it by a different name. So, we never delivered Virupaksha

or any equivalent to Air Force as yet. So that is the wrong information you have received. So,

we have our own versions of it. And we believe that, that will also be taken up by Air Force in

the coming years. But because of the uncertainty and time lines, which I can't predict, we've not

given revenue expectations out of those things and in our opening remarks.

Similarly,  when  you  talk  about  anti-drone,  yes,  products  are  getting  done.  We  will  be

participating  in demonstrating  the  products  to  army  and  air  force  and  whatever.  So  that  will

happen.  But  again,  we  don't  have  clear  time  lines  when  what  will  happen.  We  have  started

quoting in some locations.

And if we are successful, the quotes, we will -- may get the order. But these are all things which

is again a quote and competition basis. So time lines are -- and the revenue model is not -- what

do you say, very clear now. So -- but then we need to expand the product portfolio and be aware

of what is happening and the need of the customer is trying to address the need in overall. So

we're developing a number of products.

And these are all repurposed products. Already we have done something, an incremental effort

of 3, 4 months, I can position the products. So, it makes sense to do that. And our product will

be reliable and meeting the specifications. So, we believe that there will be some revenue model

going ahead, but I can't predict anything at the present moment.

On new product development, we don't do revenue projections unless the clarity is there for the

market and it is an acceptance stage and later requirements or inquiries start coming in, I can't

give you projections.

I'm only talking about the overall business environment and product development to help the

investors to understand how scalability we are going to ensure that we can be a larger business

going ahead in the next 2, 3 years' time. That is how the overall business perspective and product

development  has  been  explained,  not  to  the  exact  revenue  model,  because  I  can't  give  you

numbers like that.

Dipen Vakil:

I'm also looking for the time line on the new product development as to when we can expect the

new products to start coming into your product portfolio per se?

S. Rangarajan:

That will all happen as it's happening already, but that depends on the product. Anti-drone is a

smaller system, so it can happen quickly. But the other, the EW suite for self-jammer is a 2-year,

2.5-year  initiative,  which  we've  taken  on.  And  that  is  in  the  next  1  year,  it  will  come  to

conclusion. It depends on the product and the complexity of the project and program and the

acceptance models. Air trials have to be done, it takes longer time. It takes 1.5 to 2 years' time

to do air trials. So why I give  you the overall perspective is that, we are not only looking at

contracts now. We're also looking at shorter term, some kind of product initiatives and repeat

contracts.

Page 17 of 20

Data Patterns (India ) Limited
May 15, 2026

Slightly  immediate  term,  we've  already  invested  and  continue  to  invest  in  new  products  and

products, which is actually needed by the country, which is not position -- no Indian company

is positioning. Only foreigners are positioning products there.

So, in competition to products, our products should be far more economically priced and support

systems are going to be far superior as long as the product meets world-class specifications. So

based on that, we believe there are low-hanging fruits, but time lines are not predictable. So, we

will not predict time lines and revenue models out of that.

Moderator:

Next question is from the line of Aditya from Avendus Institutional Equities.

Aditya:

Congratulations on your set of numbers. My doubt is regarding our competitive peer, which is

Astra  Microwave.  I  have  been  following  the  defence  companies  as  such.  In  this  case,  Astra

Microwave is also like in line with providing more on complete system like similar to us.

They have been transitioning in that aspect. So how are we trying to position ourselves in case

of the competitive trends when compared to one such peer like, let's say, Astra Microwave, in

case of systems and the orders which we have received?

S. Rangarajan:

I  wouldn't  like  to  comment  on  specific  competition  on  open  line.  So,  I  will  refrain  from

answering this question.

Aditya:

So  that's  all  question  from  my  side,  sir.  If  possible,  could  you  just  explain  more  on  our

technological side in case of our product development, which is part of our R&D assets, like

details more on the technical part of it?

S. Rangarajan:

Yes.  We  have  a  strong  in-house  technology  development  team.  We  are  nearly  about  1,200

engineers working with us. So as what we've done all through the years, we develop products

and write off the revenue expenses, except in a few cases where we did a few of the fund product

development, which is capitalized. We don't do capitalizing.

We continue to do enormous amount of product development as part of our yearly requirements

and then have the product ready for markets, which we perceive or we believe is going to open

up to us. So we take such kind of initiatives and upfront invest products. And we're investing

now products on radars a full -- earlier only hardware is being done by us because the DRDO

software is done by them.

However the market has opened up, we decided that we build the software and full radars. So

we've done a few radars and some of them have been exported. Now we're building the drone

detection radars. We want to get into the airborne radar programs. So we are doing the airborne

development programs for airborne radars, including software, complete radars. We were doing

the IFF. We want to do the mission systems. We want to do the EW, already flying. So, we want

to enhance the scale of EW.

The  communication  intelligence,  we  want  to  do  world-class  systems,  the  increasing

specifications to see that it is a top of line world-class specifications are met. So like that, in

Page 18 of 20

Data Patterns (India ) Limited
May 15, 2026

every product area, we're trying to improve the product capability and address it to the world

markets and see that we are in line with the world systems so that we can offer best solutions to

India and not -- second to none is what we're trying to do.

So, our area of focus is, if you take avionics, radio, mission systems, communications, radar,

EW,  IFF,  a  lot  of  other  things  which  goes  into  UAV  platforms  and  parts of  the  radar  as  for

DRDO requirements, complete radar solutions wherever we can do that, export of these parts of

systems to international OEMs, all of this is what we're looking at.

We have fairly deep technological capabilities in all of them. And we have a very strong group

of people who have been with this company for 20, 25 years who will drive this technology and

also the middle management on engineering for all 15, 20 years in the company.

So, there's a very -- it's a very homegrown kind of an organization where there are no levels and

product talks and all of us is in. So, the idea is to develop products which is world-class with the

market opening up and we want to build a large-scale company moving ahead.

Moderator:

Ladies and gentlemen, we will take that as the last question for today. I now hand the conference

over to the management for closing comments.

S. Rangarajan:

Thank you all for joining in on this conference call, earnings call for Q4 and the year '25 - '26.

I've taken time to give you an overall perspective of how our business is growing and where we

are trying to develop products. The intent is to see that we scale up multiple times in the coming

years.

The market opportunities are very, very large, considering that India has been importing all our

defence systems and these are core competency in IP-driven products. We have been completely

dependent on foreign OEMs who don't share the details and do a manufacturing only in India.

As against that, we want to build our own capability in full products to see that we are completely

self-reliant  and  with  world-class  products.  Some  of  our  initiatives  have  started  giving  some

results and some orders are going to come on the EW, which we're competing with Germany.

We  got  some  contract  --  we're  going  to  get  some  contracts.  Tenders  have  been  opened  and

negotiation completed.

So, things like that. Similarly, on the EW jamming, we have done all this, including the software,

the  mechanical  systems,  the  cooling  systems,  the  electronics,  which  is  world-class.  So,  we

believe that also should give us some substantial revenue opportunities going ahead.

The  third  area  is  what  we've  already  developed,  and  we've  taken  some  additional  risks  in

addressing these opportunities because we believe it will help us build scale and repeat orders

as  well  as  build  program  management  capabilities  in  the  company.  If  you  take  them  and

successfully executed the contracts, customers are quite happy. So we believe that there will be

some additional requirements will come up, which will build scale into the company.

Page 19 of 20

Data Patterns (India ) Limited
May 15, 2026

Fourthly  is  we  are  looking  at  exports.  Till  now  that  has  not  been  a  focus  area.  But  with  the

geopolitical environment, the export then now takes a precedence because a lot of warehousing

companies are looking at how quickly can we deliver products for their military programs. So

we're trying to address it. And similarly, in U.S. programs.

And we need to now have a team to go and address in Japan, to Korea, to Europe, to U.K., to

other countries, including U.S. So that we are trying to put a team together to see how to address

this. We're also looking at how do we scale capabilities in terms of electro optics. So what is it

we need to do to build an electro optics, not just electronics company and domain.

So domain and electronics, mechanical, all we integrated together to build their own systems.

So I'll give you an overall idea. We are very bullish, like I said, on the growth opportunity of

what India offers today. And since we've been importing everything, now it is up to us for grabs.

Obviously, there are time lapse and it's government agencies, so we need to be aware of that and

not do overinvestment and then have competition foreigners who come on the back route and

put in infrastructure and use the business. So, we are cautious of the development and what we

are putting money in.

So -- but overall, I think we are taking the right approach and direction. And the Board and the

technology Board and the company are quite clear that we're going in the right track. So, we will

continue to build like this and scale the company quite quickly. This is what we expect. We're

very bullish on Data Patterns growth going ahead.

Thank you very much for your listening patiently for this. If you have any further questions,

please pass it on to Go India Advisors, and we'll get them answered to you through them. Thank

you all. Thanks for listening in.

Moderator:

Thank you very much. On behalf of Go India Advisors, that concludes this conference. Thank

you all for joining us today, and you may now disconnect your lines.

Page 20 of 20


